package com.example.pass24final;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONObject;

import java.util.ArrayList;

public class pass_form3 extends AppCompatActivity implements PaymentResultListener {


    TextView username, name;
    TextInputEditText price;
    TextInputLayout upiid, note;
    String usernamefb, namefb, pricefb, city;
    FirebaseDatabase namefirebaseDatabase, paymentfirebaseDatabase, paidUserfirebaseDatabase, database;
    DatabaseReference namedatabaseReference, paymentdatabaseReference, paidUserdatabaseReference, refrence;
    final int UPI_PAYMENT = 0;

    String sPaymentType = "", sTransactionId = "";
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pass_form3);

        Button paynow_btn = findViewById(R.id.paynow_btn);

        paynow_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                razorPayPaymentMethod();
            }
        });

        Intent intent = getIntent();
        usernamefb = intent.getStringExtra("username_passform2_to_passform3");

        username = findViewById(R.id.username_passform3);
        name = findViewById(R.id.name_passform3);
        price = findViewById(R.id.price_passform3);
        upiid = findViewById(R.id.upi_id_passform3);
        note = findViewById(R.id.upi_note_passform3);

        city = "Ahmedabad2Rajkot";

        username.setText(usernamefb);


        namefirebaseDatabase = FirebaseDatabase.getInstance();
        namedatabaseReference = namefirebaseDatabase.getReference("users");

        database = FirebaseDatabase.getInstance();
        refrence = namefirebaseDatabase.getReference("passRelatedInfo");

        paymentfirebaseDatabase = FirebaseDatabase.getInstance();
        paymentdatabaseReference = paymentfirebaseDatabase.getReference("passRelatedInfo");

        paidUserfirebaseDatabase = FirebaseDatabase.getInstance();
        paidUserdatabaseReference = paidUserfirebaseDatabase.getReference("PaidUserDetails");


        getName();
        getPrice();
    }

    private void razorPayPaymentMethod() {
        final Activity activity = this;

        final Checkout co = new Checkout();

        try {
            JSONObject options = new JSONObject();
            options.put("name", "Pass 24");
            //options.put("description", "Demoing Charges");
            options.put("description", "Product Details");
            options.put("send_sms_hash", true);
            options.put("allow_rotation", true);
            //You can omit the image option to fetch the image from dashboard
            options.put("image", "https://s3.amazonaws.com/rzp-mobile/images/rzp.png");
            options.put("currency", "INR");
            options.put("amount", Double.parseDouble(price.getText().toString()) * 100);
//            options.put("amount", Double.parseDouble(String.valueOf(iTotal)) * 100);

            JSONObject preFill = new JSONObject();
            preFill.put("email", "vaghelajay960@gmail.com");
            preFill.put("contact", "9104514607");

            options.put("prefill", preFill);

            co.open(activity, options);
        } catch (Exception e) {
            Log.d("RESPONSE", e.getMessage());
            Toast.makeText(activity, "Error in payment: " + e.getMessage(), Toast.LENGTH_SHORT)
                    .show();
            e.printStackTrace();
        }
    }


    @Override
    public void onPaymentSuccess(String razorpayPaymentID) {
        try {
            Toast.makeText(this, "Payment Successful: " + razorpayPaymentID, Toast.LENGTH_SHORT).show();
            sTransactionId = razorpayPaymentID;
            sPaymentType = "Online";
//            if (new ConnectionDetector(CartActivity.this).isConnectingToInternet()) {
//                if(new ConnectionDetector(CartActivity.this).isConnectingToInternet()){
                    pd = new ProgressDialog(this);
                    pd.setMessage("Please Wait...");
                    pd.setCancelable(false);
                    pd.show();
                    startActivity(new Intent(this,passActivity.class));
//                    addOrder();
//                }
//                else{
//                    new ConnectionDetector(CartActivity.this).connectiondetect();
//                }
//            } else {
//                new ConnectionDetector(CartActivity.this).connectiondetect();
//            }
        } catch (Exception e) {
            Log.e("RESPONSE", "Exception in onPaymentSuccess", e);
        }
    }

    @Override
    public void onPaymentError(int code, String response) {
        try {
            Log.d("RESPONSE", "Payment Cancelled " + code + " " + response);
            //Toast.makeText(this, "Payment failed: " + code + " " + response, Toast.LENGTH_SHORT).show();
            Toast.makeText(this, "Payment Cancelled", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e("RESPONSE", "Exception in onPaymentError", e);
        }
    }

    private void getName() {
        namedatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                namefb = snapshot.child(usernamefb).child("name").getValue(String.class);
                name.setText(namefb);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void getPrice() {
        paymentdatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                pricefb = snapshot.child(city).child("Price").getValue(String.class);
                price.setText(pricefb);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }


    public void paymentMethod(View view) {
        String upi_id = upiid.getEditText().getText().toString();
        String upi_note = note.getEditText().getText().toString();

        if (!upi_id.isEmpty()) {
            upiid.setError(null);
            upiid.setErrorEnabled(false);
            if (upi_id.matches("[a-zA-Z0-9.\\-_]{2,256}@[a-zA-Z]{2,64}")) {

                registerPaymnetIndatabase(upi_id, usernamefb, upi_note, pricefb);
            } else {
                upiid.setError("Invalid UPI id");
            }
        } else {
            upiid.setError("Enter UPI id");
        }

    }

    private void registerPaymnetIndatabase(String upi_id, String username, String note, String price) {
        paidUserdatabaseReference.child(username).child("upiid").setValue(upi_id);
        paidUserdatabaseReference.child(username).child("upi note").setValue(note);
        paidUserdatabaseReference.child(username).child("price paid").setValue(price);
        //Toast.makeText(this, "You are broke " + upi_id, Toast.LENGTH_SHORT).show();

        PayUsingUPI(upi_id, username, note, price);

//        Intent intent = new Intent(pass_form3.this,download_pdf.class);
//        intent.putExtra("username_home_to_downloadpdf",username);
//        startActivity(intent);
    }

    private void PayUsingUPI(String upi_id, String username, String note, String price) {
        Uri uri = Uri.parse("upi://pay").buildUpon()
                .appendQueryParameter("pa", "rohansuthar6501-1@okaxis")
                .appendQueryParameter("pn", "Pass 24")
                .appendQueryParameter("tn", note)
                .appendQueryParameter("am", price)
                .appendQueryParameter("cu", "INR")
                .build();

        Intent upiPayIntent = new Intent(Intent.ACTION_VIEW);
        upiPayIntent.setData(uri);

        Intent chooser = Intent.createChooser(upiPayIntent, "Pay using");

        if (null != chooser.resolveActivity(getPackageManager())) {
            startActivityForResult(chooser, UPI_PAYMENT);
        } else {
            Toast.makeText(this, "No UPI app found please install one to continue", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case UPI_PAYMENT:
                if ((RESULT_OK == resultCode) || (resultCode == 11)) {
                    if (data != null) {
                        String trxt = data.getStringExtra("response");
                        Log.d("UPI", "onActivityResult: " + trxt);
                        ArrayList<String> dataList = new ArrayList<>();
                        dataList.add(trxt);
                        upiPaymentDataOperation(dataList);
                    } else {
                        Log.d("UPI", "onActivityResult: " + "Return data is null");
                        ArrayList<String> dataList = new ArrayList<>();
                        dataList.add("nothing");
                        upiPaymentDataOperation(dataList);
                    }
                } else {
                    Log.d("UPI", "onActivityResult: " + "Return data is null"); //when user simply back without payment
                    ArrayList<String> dataList = new ArrayList<>();
                    dataList.add("nothing");
                    upiPaymentDataOperation(dataList);
                }
                break;
        }
    }


    private void upiPaymentDataOperation(ArrayList<String> data) {
        if (isConnectionAvailable(pass_form3.this)) {
            String str = data.get(0);
            Log.d("UPIPAY", "upiPaymentDataOperation: " + str);
            String paymentCancel = "";
            if (str == null) str = "discard";
            String status = "";
            String approvalRefNo = "";
            String response[] = str.split("&");
            for (int i = 0; i < response.length; i++) {
                String equalStr[] = response[i].split("=");
                if (equalStr.length >= 2) {
                    if (equalStr[0].toLowerCase().equals("Status".toLowerCase())) {
                        status = equalStr[1].toLowerCase();
                    } else if (equalStr[0].toLowerCase().equals("ApprovalRefNo".toLowerCase()) || equalStr[0].toLowerCase().equals("txnRef".toLowerCase())) {
                        approvalRefNo = equalStr[1];
                    }
                } else {
                    paymentCancel = "Payment cancelled by user.";
                }
            }

            if (status.equals("success")) {
                //Code to handle successful transaction here.
                Toast.makeText(pass_form3.this, "Transaction successful.", Toast.LENGTH_SHORT).show();
                Log.d("UPI", "responseStr: " + approvalRefNo);
                Intent intent = new Intent(pass_form3.this, download_pdf.class);
                intent.putExtra("username_passform3_to_passActivity", usernamefb);
                startActivity(intent);
            } else if ("Payment cancelled by user.".equals(paymentCancel)) {
                Toast.makeText(pass_form3.this, "Payment cancelled by user.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(pass_form3.this, "Transaction failed.Please try again", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(pass_form3.this, "Internet connection is not available. Please check and try again", Toast.LENGTH_SHORT).show();
        }
    }

    public static boolean isConnectionAvailable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager != null) {
            NetworkInfo netInfo = connectivityManager.getActiveNetworkInfo();
            if (netInfo != null && netInfo.isConnected()
                    && netInfo.isConnectedOrConnecting()
                    && netInfo.isAvailable()) {
                return true;
            }
        }
        return false;
    }
}

