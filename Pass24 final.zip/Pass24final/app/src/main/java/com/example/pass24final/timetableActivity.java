package com.example.pass24final;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.StorageReference;

public class timetableActivity extends Activity {
    ImageView UserAddharCard;
    Button uploadBtn;
    ProgressBar progressBar;
    FirebaseDatabase imgFirebaseDatabase;
    DatabaseReference imgFatabaseReference;
    StorageReference storageReference;

    Button next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_table);

//        uploadBtn = findViewById(R.id.update_btn_test);
//        progressBar = findViewById(R.id.progress_bar_test);
//        UserAddharCard = findViewById(R.id.upload_img);
//        imgFirebaseDatabase = FirebaseDatabase.getInstance();
//        imgFatabaseReference = imgFirebaseDatabase.getReference("userAddharCard");
//        storageReference = FirebaseStorage.getInstance().getReference();
//
//        UserAddharCard.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent galleryIntent = new Intent();
//                galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
//                galleryIntent.setType("image/*");
//                startActivityForResult(galleryIntent, 2);
//            }
//        });

//        @Override
//        protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data){
//            super.onActivityResult(requestCode, resultCode, data);
//                if(requestCode == 2 ,)
//            }


        next = findViewById(R.id.tt_test);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //   Toast.makeText(getActivity(), "" + data.getString("username_homeActivity_to_homeFragment"), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(timetableActivity.this,pass_form1.class);
                //intent.putExtra("username_home_to_passform1",username_home);
                startActivity(intent);
            }
        });
    }

    public void openDatePicker(View view) {
    }
}
