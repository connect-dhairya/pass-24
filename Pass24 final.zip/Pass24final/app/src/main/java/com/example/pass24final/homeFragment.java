package com.example.pass24final;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class homeFragment extends Fragment {

    String username_home;
    TextView title;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home,container,false);


        title = view.findViewById(R.id.title_home_fragment);

        FirebaseDatabase namefirebaseDatabase;
        DatabaseReference namedatabaseReference;


        namefirebaseDatabase = FirebaseDatabase.getInstance();
        namedatabaseReference = namefirebaseDatabase.getReference("users");

        namedatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String namefb =  snapshot.child(username_home).child("name").getValue(String.class);
                title.setText("Welcome " + namefb);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        Bundle data = this.getArguments();
        //title.setText(data.getString("username_homeActivity_to_homeFragment"));

        username_home = data.getString("username_homeActivity_to_homeFragment");



        CardView applyPass = view.findViewById(R.id.card_apply_pass);
        CardView renewPass = view.findViewById(R.id.card_renew_pass);
        CardView timeTable = view.findViewById(R.id.timetable_home);
        CardView downloadPdf = view.findViewById(R.id.download_pdf_home);
        applyPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // Toast.makeText(getActivity(), "" + username_home, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getContext(),pass_form1.class);
                intent.putExtra("username_home_to_passform1",username_home);
                startActivity(intent);
            }
        });
        renewPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(getActivity(), "Hello", Toast.LENGTH_SHORT).show();
                Intent renewIntent = new Intent(getContext(),timetableActivity.class);
//                renewIntent.putExtra("username_home_to_passform1",username_home);
                startActivity(renewIntent);
            }
        });
        timeTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //   Toast.makeText(getActivity(), "" + data.getString("username_homeActivity_to_homeFragment"), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getContext(), renewpassActivity.class);
//                intent.putExtra("",username_home);
                startActivity(intent);
            }
        });
        downloadPdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //   Toast.makeText(getActivity(), "" + data.getString("username_homeActivity_to_homeFragment"), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getContext(),download_pdf.class);
                intent.putExtra("username_home_to_downloadpdf",username_home);
                startActivity(intent);
            }
        });
        return view;
    }
}