package com.example.pass24final;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Sign_up_Activity extends AppCompatActivity {

    TextInputLayout RegEmail,RegPassword,RegName,RegPhoneNumber,RegUsername;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        RegEmail = findViewById(R.id.email);
        RegPassword = findViewById(R.id.password);
        RegUsername = findViewById(R.id.username);
        RegName = findViewById(R.id.fullname);
        RegPhoneNumber = findViewById(R.id.phoneNumber);
        firebaseDatabase = FirebaseDatabase.getInstance();
        reference = firebaseDatabase.getReference("users");
    }


    public void registerUser(View view) {
//        Toast.makeText(Sign_up_Activity.this, "Hello", Toast.LENGTH_SHORT).show();

        String name = RegName.getEditText().getText().toString();
        String username = RegUsername.getEditText().getText().toString();
        String phoneNumber = RegPhoneNumber.getEditText().getText().toString();
        String email = RegEmail.getEditText().getText().toString();
        String password = RegPassword.getEditText().getText().toString();

        if(!name.isEmpty()){
            RegName.setError(null);
            RegName.setErrorEnabled(false);
            if(!username.isEmpty()){
                RegUsername.setError(null);
                RegUsername.setErrorEnabled(false);
                if(!phoneNumber.isEmpty()){
                    RegPhoneNumber.setError(null);
                    RegPhoneNumber.setErrorEnabled(false);
                    if(!email.isEmpty()){
                        RegEmail.setError(null);
                        RegEmail.setErrorEnabled(false);
                        if(!password.isEmpty()){
                            RegPassword.setError(null);
                            RegPassword.setErrorEnabled(false);
                            if(email.matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+")){

                                registerUserIndatabase();
                            }else{
                                RegEmail.setError("Invalid email address");
                            }
                        }else{
                            RegPassword.setError("Password cannot be empty");
                        }
                    }else{
                        RegEmail.setError("Email cannot be empty");
                    }
                }else{
                    RegPhoneNumber.setError("Phone number cannot be empty");
                }
            }else{
                RegUsername.setError("Field cannot be empty");
            }
        }else{
            RegName.setError("Field cannot be empty");
        }
    }

    private void registerUserIndatabase() {

        String name_s = RegName.getEditText().getText().toString();
        String username_s = RegUsername.getEditText().getText().toString();
        String phoneNumber_s = RegPhoneNumber.getEditText().getText().toString();
        String email_s = RegEmail.getEditText().getText().toString();
        String password_s = RegPassword.getEditText().getText().toString();

        CheckIfUserAlreadyExist();

        StoringData storingData = new StoringData(name_s , username_s, email_s, password_s, phoneNumber_s);
        reference.child(username_s).setValue(storingData);

        String final_data_string = username_s;

        //Toast.makeText(this, "Data Stored", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(Sign_up_Activity.this,HomeActivity.class);
        intent.putExtra("final_data",final_data_string);
        startActivity(intent);
        finish();
    }

    private void CheckIfUserAlreadyExist() {
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String username_check = RegUsername.getEditText().getText().toString();
                String name_check = snapshot.child(username_check).child("name").getValue(String.class);

                Toast.makeText(Sign_up_Activity.this, "Checked"+name_check, Toast.LENGTH_SHORT).show();
//                if(!name_check.equals(null)){
//                    RegUsername.setError(null);
//                    RegUsername.setErrorEnabled(false);
//                }else{
//                    RegUsername.setError("Username already exist");
//                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void backTOLogin(View view) {
        Intent intent = new Intent(Sign_up_Activity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}
