package com.example.pass24final;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity {

    ImageView image;
    TextView title,topic;
    TextInputLayout username,password;
    Button go,signUp;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        username = findViewById(R.id.usernameLogin);
        go = findViewById(R.id.go_btn);
        signUp = findViewById(R.id.sign_btn);
        go = findViewById(R.id.go_btn);
        title = findViewById(R.id.welcome_string);
        topic = findViewById(R.id.sign_text);
        password =  findViewById(R.id.passwordLogin);


        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String txt_username = username.getEditText().getText().toString();
                String txt_password = password.getEditText().getText().toString();

                if(!txt_username.isEmpty()){
                    username.setError(null);
                    username.setErrorEnabled(false);
                    if(!txt_password.isEmpty()){
                        password.setError(null);
                        password.setErrorEnabled(false);

                        loginTODatabase();

                    }else{
                        password.setError("password cannot be empty");
                    }
                }else{
                    username.setError("username cannot be empty");
                }

            }

        });

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this,Sign_up_Activity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void loginTODatabase() {

        final String username_data = username.getEditText().getText().toString();
        final String password_data = password.getEditText().getText().toString();

        firebaseDatabase = FirebaseDatabase.getInstance();
        reference = firebaseDatabase.getReference("users");

        Query check_username = reference.orderByChild("username").equalTo(username_data);

        check_username.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    username.setError(null);
                    username.setErrorEnabled(false);
                    String passwordCheck = snapshot.child(username_data).child("password").getValue(String.class);
                    if(passwordCheck.equals(password_data)){
                        password.setError(null);
                        password.setErrorEnabled(false);

//                        String nameGetter = snapshot.child(username_data).child("name").getValue(String.class);
//                        String emailGetter = snapshot.child(username_data).child("email").getValue(String.class);
//                        String phoneGetter = snapshot.child(username_data).child("phoneNumber").getValue(String.class);
//                        String usernameGetter = snapshot.child(username_data).child("username").getValue(String.class);

                      //  Toast.makeText(LoginActivity.this, "" + nameGetter, Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(),HomeActivity.class);

                       /// String final_data_string = usernameGetter + "_" + nameGetter + "%" + emailGetter + "$" + phoneGetter;

//                        intent.putExtra("name",nameGetter);
//                        intent.putExtra("email",emailGetter);
//                        intent.putExtra("username",usernameGetter);
//                        intent.putExtra("phoneNumber",phoneGetter);

                        intent.putExtra("final_data",username_data);

//                        Toast.makeText(LoginActivity.this, "Login successfull " + final_data_string, Toast.LENGTH_SHORT).show();
                        startActivity(intent);

                        finish();

                    }else{
                        password.setError("Wrong password");
                    }
                }else{
                    username.setError("username doesn't exist");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}
