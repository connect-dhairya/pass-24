package com.example.pass24final;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.navigation.NavigationView;

//import com.google.firebase.auth.FirebaseAuth;

public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;
    ActionBarDrawerToggle actionBarDrawerToggle;
    String total_string;
    CardView applyPass ,renewPass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Intent intent = getIntent();
        total_string = intent.getStringExtra("final_data");

        //hooks
        toolbar = findViewById(R.id.toolbar);
        drawerLayout = findViewById(R.id.drawablelayout);
        navigationView = findViewById(R.id.navigation_bar);
        applyPass = findViewById(R.id.card_apply_pass);
        renewPass = findViewById(R.id.card_renew_pass);

        //toolbar
        setSupportActionBar(toolbar);

        //Navigation Drawer Menu
        navigationView.bringToFront();
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_open, R.string.navigation_close);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);

        navigationView.setCheckedItem(R.id.home_menu);

        if(savedInstanceState == null){
//            Toast.makeText(this, "" + total_string, Toast.LENGTH_SHORT).show();

            Bundle data = new Bundle();
            data.putString("username_homeActivity_to_homeFragment",total_string);

            Fragment fragment = new homeFragment();
            fragment.setArguments(data);
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.fragment_container,fragment).commit();

        }

    }



    //Hide some items
//    Menu menu = navigationView.getMenu();
//    menu.findItem(R.id.logout_menu).setVisible(false);
    @Override
    public void onBackPressed() {
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case R.id.home_menu:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new homeFragment()).commit();
                break;
            case R.id.personal_details_menu:
                //getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new profileFragment()).commit();
                Intent profileintent = new Intent(HomeActivity.this,profile.class);
                profileintent.putExtra("total_string",total_string);
                startActivity(profileintent);
                break;
//            case R.id.pass_details_menu:
//                Intent passDetailIntent = new Intent(HomeActivity.this, pass_form1.class);
//                startActivity(passDetailIntent);
//                break;
//            case R.id.time_table:
//                Intent timetableintent = new Intent(HomeActivity.this, TimeTableActivity.class);
//                startActivity(timetableintent);
//                break;
            case R.id.logout_menu:
                Toast.makeText(this, "logout", Toast.LENGTH_SHORT).show();
                Intent logoutintent = new Intent(HomeActivity.this, LoginActivity.class);
                startActivity(logoutintent);
                break;
            case R.id.share_menu:
                Toast.makeText(this, "Share", Toast.LENGTH_SHORT).show();
                break;
            case R.id.privacy_policy_menu:
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new privacyPolicyFragment()).commit();
                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }



//        applyPass.setOnClickListener(new View.OnClickListener() {
//        public void onClick(View view) {
//            //Toast.makeText(getActivity(), "" +username_home , Toast.LENGTH_SHORT).show();
//            Intent intent = new Intent(HomeActivity(),pass_form1.class);
//            //intent.putExtra("username",username_hom);
//            startActivity(intent);
//        }
//    });
//        renewPass.setOnClickListener(new View.OnClickListener() {
//        public void onClick(View view) {
//           // Toast.makeText(getActivity(), "Hello", Toast.LENGTH_SHORT).show();
//            Intent renewIntent = new Intent(HomeActivity(),testActivity.class);
//            startActivity(renewIntent);
//        }
    //});
}